import React, { Component } from 'react'
import "./Aboutus.css"


export default class Aboutus extends Component {
    
    render() {
        return (
            <div>
                <p className="pa" >Este proyecto esta elaborado por los estudiantes tlataltal con el fin 
                de visualizar los datos de la ubicación geografica enviados desde los dispositivos gps
                </p>
                
            </div>
        )
    }
}
